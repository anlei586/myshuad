<?php


$dispose_status = array(
 "支付中"=>"wc-pending"
,"处理中"=>"wc-processing"
,"暂缓"=>"wc-on-hold"
,"完成"=>"wc-completed"
,"取消"=>"wc-cancelled"
,"退货"=>"wc-refunded"
,"失败"=>"wc-failed"

 );


?>
